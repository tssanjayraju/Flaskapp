from flask import Flask, render_template, abort, jsonify, request, redirect, url_for
from model import db, save_db
import pyodbc

app = Flask(__name__)


def connection():
    s = 'DESKTOP-M2MT153\SQLEXPRESS'  # Your server name
    d = 'FlaskDemo'
    u = 'testuser1'  # Your login
    p = 'testuser1'  # Your login password
    cstr = 'DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + \
        s+';DATABASE='+d+';UID='+u+';PWD=' + p
    conn = pyodbc.connect(cstr)
    return conn


@app.route("/")
def welcome():
    print('Sanjay Raju')
    return render_template("welcome.html",
                           message="Here's a message from view.",
                           cards=db)


@app.route("/card/<int:index>")
def card_view(index):
    try:
        card = db[index]
        return render_template("card.html", card=card, index=index, max_index=len(db) - 1)

    except IndexError:
        abort(404)
        # print('abort')


@app.route('/add_card', methods=["GET", "POST"])
def add_card():
    if request.method == "POST":
        newCard = {"question": request.form['question'],
                   "answer": request.form['answer']}
        db.append(newCard)
        save_db()

        # save data to Card table in SQL server
        # conn = connection()
        # cursor = conn.cursor()
        # cursor.execute("INSERT INTO dbo.Cards (question,answer) VALUES ('"+ request.form['question'] + "','" + request.form['answer']+ "')")
        # conn.commit()

        return redirect(url_for('card_view', index=len(db)-1))

    else:
        return render_template('add_card.html')


@app.route('/remove_card/<int:index>', methods=["GET", "POST"])
def remove_card(index):
    try:

        if (request.method == "POST"):
            del db[index]
            save_db()
            return redirect(url_for('welcome'))
        else:
            return render_template("remove_Card.html", card=db[index])
    except IndexError:
        abort(404)


@app.route("/api/card/")
def api_card_list():
    testdata = []
    conn = connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM dbo.Cards")
    for row in cursor.fetchall():
        testdata.append({"Title": row[0], "Id": row[1]})
    conn.close()

    # print(testdata)
    return jsonify(db)


@app.route("/api/card/<int:id>")
def api_card_detail(id):
    try:

        testdata = ''
        conn = connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM dbo.Test where Id = " + str(id))
        for row in cursor.fetchall():
            testdata = {"Title": row[0], "Id": row[1]}
        conn.close()

        return testdata

    except IndexError:
        abort(404)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)
